
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { CanDeactivate } from '../../../node_modules/@angular/router';
import { Injectable } from '../../../node_modules/@angular/core';

@Injectable()
export class CanDeactivateGuardService implements CanDeactivate<CreateEmployeeComponent> {
    canDeactivate(componet: CreateEmployeeComponent): boolean {
        if (componet.createEmployeeForm.dirty && !componet.createEmployeeForm['submitted']) {
            return confirm('Are you sure want to discard the changes ?');
        } else { return true; }
    }
}
