import { Router } from '@angular/router';
import { Employee } from './../model/employee.model';
import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';

@Component({
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {
   searchTerm = '';
  employees: Employee[];
  employeeToShow: Employee;
  arrEmployeeToShow: Employee[] = [];
  employeeToShowCount = 0;
  blDisplayAll = false;
  ShowNotifyData: Employee;
  constructor(private _employees: EmployeeService, private _router: Router) {
  }

  ngOnInit() {
    this.employees = this._employees.GetEmployeeDetails();
    this.employeeToShow = this.employees[this.employeeToShowCount];
    this.arrEmployeeToShow.push(this.employees[this.employeeToShowCount]);
  }
  showNextEmployee(): void {
    this.blDisplayAll = false;
    this.arrEmployeeToShow = [];
    if (this.employeeToShowCount === this.employees.length - 1) {
      this.employeeToShowCount = 0;
    } else {
      this.employeeToShowCount++;
    }
    this.employeeToShow = this.employees[this.employeeToShowCount];
    this.arrEmployeeToShow.push(this.employees[this.employeeToShowCount]);
  }
  viewAll(): void {
    this.blDisplayAll = true;
    this.employeeToShowCount = -1;
    this.arrEmployeeToShow = this.employees;
  }
  getEmployeeDetails(id: number): void {
    this._router.navigate(['/employee', id]);
  }
}
