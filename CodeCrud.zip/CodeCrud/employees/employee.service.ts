import { Employee } from './../model/employee.model';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private employee: Employee[] = [
    {
      id: 1,
      name: 'Harinder',
      gender: 'Male',
      email: 'harinder.k@idsil.com',
      dateOfBirth: '14/07/1990',
      phoneNumber: 1234567890,
      PhotoPath: 'assets/images/img1.jpg',
      Department: '2'
    },
    {
      id: 2,
      name: 'Yadvinder',
      gender: 'Male',
      email: 'yad@ps.com',
      dateOfBirth: '14/07/1990',
      phoneNumber: 1122334455,
      PhotoPath: 'assets/images/img2.jpg',
      Department: '1'
    },
    {
      id: 3,
      name: 'Yashwant',
      gender: 'Male',
      email: 'yashi@g.com',
      dateOfBirth: '14/07/1990',
      phoneNumber: 5566778899,
      PhotoPath: 'assets/images/img3.jpg',
      Department: '3'
    }
  ];
  GetEmployeeById(id: number): Employee {
    return this.employee.find(x => x.id === id);
  }
  GetEmployeeByName(Name: string): Employee {
    return this.employee.find(x => x.name.includes(Name));
  }
  GetEmployeeDetails(): Employee[] {
    return this.employee;
  }
  SaveEmployee(_employee: Employee) {
    _employee.id = this.employee.length + 1;
    this.employee.push(_employee);
  }
  constructor() { }
}
