import { Employee } from './../model/employee.model';
import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';
import { ActivatedRoute, Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
  _id: number;
  _TotalEmployees: number;
  employees: Employee;
  constructor(private _employeeService: EmployeeService, private _route: ActivatedRoute, private _router: Router) { }

  ngOnInit() {
    // this._id = +this._route.snapshot.paramMap.get('id');
    this._route.paramMap.subscribe(params => {
      this._id = +params.get('id');
      this.employees = this._employeeService.GetEmployeeById(this._id);
      this._TotalEmployees = this._employeeService.GetEmployeeDetails().length;
    });
  }
  ViewNextEmployee(): void {
    if (this._id < this._TotalEmployees) {
      this._id = this._id + 1;
    } else {
      this._id = 1;
    }
    this.employees = this._employeeService.GetEmployeeById(this._id);
    this._router.navigate(['/employee', this._id]);
  }
}

