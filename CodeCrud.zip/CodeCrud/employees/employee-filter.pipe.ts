import { Employee } from './../model/employee.model';
import { PipeTransform, Pipe } from '../../../node_modules/@angular/core';

@Pipe({
name: 'employeeFilter'
})

export class EmployeeFilterPipe implements PipeTransform {
    transform(employees: Employee[], searchText: string): Employee[] {
        if (!employees || !searchText) {
            return employees;
        }
        return employees.filter(employee =>
            employee.name.toLowerCase().indexOf(searchText.toLowerCase()) >= 0
        );
    }
}
