import { Employee } from './../model/employee.model';
import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-display-employee',
  templateUrl: './display-employee.component.html',
  styleUrls: ['./display-employee.component.css']
})
export class DisplayEmployeeComponent implements OnInit {
  employeeId: number;
  @Input() emp: Employee;
  constructor(private _route: ActivatedRoute) { }
  ngOnInit() {
    this.employeeId = +this._route.snapshot.paramMap.get('id');
  }
  getNameAndEmail(): string {
    return this.emp.name + ' ' + this.emp.email;
  }
}
