import { Validator, NG_VALIDATORS, AbstractControl } from '../../../node_modules/@angular/forms';
import { Directive, Input } from '../../../node_modules/@angular/core';

@Directive({
    selector: '[appValidateSelect]',
    providers: [{
        provide: NG_VALIDATORS,
        useExisting: CustomValidationDirective,
        multi: true
    }]
})
export class CustomValidationDirective implements Validator {
    @Input() appValidateSelect: string;
    validate(control: AbstractControl): { [key: string]: any } | null {
        return control.value === this.appValidateSelect ? { 'defaultSelected': true } : null;
    }
}
