import { Validator, NG_VALIDATORS, AbstractControl } from '../../../node_modules/@angular/forms';
import { Directive, Input } from '../../../node_modules/@angular/core';

@Directive({
    selector: '[appCompareValidator]',
    providers: [{
        provide: NG_VALIDATORS,
        useExisting: CustomCompareValidationDirective,
        multi: true
    }]
})

export class CustomCompareValidationDirective implements Validator {
    @Input() appCompareValidator: string;
    validate(control: AbstractControl): { [key: string]: any } | null {
        const controlToCompare = control.parent.get(this.appCompareValidator);
        if (controlToCompare && controlToCompare.value !== control.value) {
            return { 'notEqual': true };
        }
        return null;
    }
}
